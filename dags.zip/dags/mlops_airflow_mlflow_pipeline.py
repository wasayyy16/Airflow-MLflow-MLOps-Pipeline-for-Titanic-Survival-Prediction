from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import mlflow
import mlflow.sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
import pickle
import os

MLFLOW_TRACKING_URI = "http://172.20.0.1:5000"
DATASET_PATH = "/opt/airflow/data/Titanic-Dataset.csv"

RUN_PARAMS = {
    "model_type": "LogisticRegression",
    "n_estimators": 100,
    "max_depth": 5,
    "C": 0.5,
    "max_iter": 300,
}

default_args = {
    "owner": "student",
    "retries": 2,
    "retry_delay": timedelta(seconds=10),
    "start_date": datetime(2024, 1, 1),
}

dag = DAG(
    "mlops_titanic_pipeline",
    default_args=default_args,
    description="Titanic survival prediction pipeline",
    schedule_interval=None,
    catchup=False,
    tags=["mlops", "titanic"],
)

# Task 2: Data Ingestion
def ingest_data(**kwargs):
    df = pd.read_csv(DATASET_PATH)
    print(f"Dataset Shape: {df.shape}")
    print(f"Missing Values:\n{df.isnull().sum()}")
    kwargs["ti"].xcom_push(key="dataset_path", value=DATASET_PATH)

task_ingest = PythonOperator(
    task_id="data_ingestion",
    python_callable=ingest_data,
    dag=dag,
)

# Task 3: Data Validation
def validate_data(**kwargs):
    ti = kwargs["ti"]
    try_number = ti.try_number
    print(f"Attempt number: {try_number}")

    df = pd.read_csv(DATASET_PATH)
    age_pct = df["Age"].isnull().mean() * 100
    emb_pct = df["Embarked"].isnull().mean() * 100
    print(f"Age missing: {age_pct:.2f}%")
    print(f"Embarked missing: {emb_pct:.2f}%")

    if try_number == 1:
        raise Exception("Intentional failure on attempt 1 - demonstrating retry!")

    if age_pct > 30:
        raise ValueError(f"Age missing too high: {age_pct:.2f}%")
    if emb_pct > 30:
        raise ValueError(f"Embarked missing too high: {emb_pct:.2f}%")

    print("Validation passed!")

task_validate = PythonOperator(
    task_id="data_validation",
    python_callable=validate_data,
    retries=2,
    retry_delay=timedelta(seconds=10),
    dag=dag,
)

# Task 4a: Handle Missing Values
def handle_missing(**kwargs):
    df = pd.read_csv(DATASET_PATH)
    df["Age"].fillna(df["Age"].median(), inplace=True)
    df["Embarked"].fillna(df["Embarked"].mode()[0], inplace=True)
    df["Cabin"].fillna("Unknown", inplace=True)
    out = "/opt/airflow/dags/titanic_missing_handled.csv"
    df.to_csv(out, index=False)
    kwargs["ti"].xcom_push(key="missing_handled_path", value=out)
    print("Missing values handled.")

task_missing = PythonOperator(
    task_id="handle_missing_values",
    python_callable=handle_missing,
    dag=dag,
)

# Task 4b: Feature Engineering
def feature_engineering(**kwargs):
    df = pd.read_csv(DATASET_PATH)
    df["Age"].fillna(df["Age"].median(), inplace=True)
    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
    df["IsAlone"] = (df["FamilySize"] == 1).astype(int)
    out = "/opt/airflow/dags/titanic_features.csv"
    df.to_csv(out, index=False)
    kwargs["ti"].xcom_push(key="features_path", value=out)
    print(f"Features created:\n{df[['FamilySize','IsAlone']].head()}")

task_features = PythonOperator(
    task_id="feature_engineering",
    python_callable=feature_engineering,
    dag=dag,
)

# Task 5: Data Encoding
def encode_data(**kwargs):
    df = pd.read_csv(DATASET_PATH)
    df["Age"].fillna(df["Age"].median(), inplace=True)
    df["Embarked"].fillna(df["Embarked"].mode()[0], inplace=True)
    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
    df["IsAlone"] = (df["FamilySize"] == 1).astype(int)
    le = LabelEncoder()
    df["Sex"] = le.fit_transform(df["Sex"])
    df["Embarked"] = le.fit_transform(df["Embarked"])
    df.drop(columns=["PassengerId", "Name", "Ticket", "Cabin"], inplace=True)
    out = "/opt/airflow/dags/titanic_encoded.csv"
    df.to_csv(out, index=False)
    kwargs["ti"].xcom_push(key="encoded_path", value=out)
    print(f"Encoding done. Columns: {list(df.columns)}")

task_encode = PythonOperator(
    task_id="data_encoding",
    python_callable=encode_data,
    dag=dag,
)

# Task 6: Model Training
def train_model(**kwargs):
    os.environ["GIT_PYTHON_REFRESH"] = "quiet"
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
    mlflow.set_experiment("titanic_survival")

    df = pd.read_csv("/opt/airflow/dags/titanic_encoded.csv")
    X = df.drop("Survived", axis=1)
    y = df["Survived"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    with mlflow.start_run() as run:
        model_type = RUN_PARAMS["model_type"]
        mlflow.log_param("model_type", model_type)
        mlflow.log_param("dataset_size", len(df))

        if model_type == "RandomForest":
            mlflow.log_param("n_estimators", RUN_PARAMS["n_estimators"])
            mlflow.log_param("max_depth", RUN_PARAMS["max_depth"])
            model = RandomForestClassifier(
                n_estimators=RUN_PARAMS["n_estimators"],
                max_depth=RUN_PARAMS["max_depth"],
                random_state=42,
            )
        else:
            mlflow.log_param("C", RUN_PARAMS["C"])
            mlflow.log_param("max_iter", RUN_PARAMS["max_iter"])
            model = LogisticRegression(
                C=RUN_PARAMS["C"], max_iter=RUN_PARAMS["max_iter"]
            )

        model.fit(X_train, y_train)

        # Save model as pickle locally
        model_path = "/opt/airflow/dags/model.pkl"
        with open(model_path, "wb") as f:
            pickle.dump(model, f)
        print(f"Model saved to {model_path}")
        X_test.to_csv("/opt/airflow/dags/X_test.csv", index=False)
        y_test.to_csv("/opt/airflow/dags/y_test.csv", index=False)

        kwargs["ti"].xcom_push(key="run_id", value=run.info.run_id)
        print(f"Model trained. Run ID: {run.info.run_id}")

task_train = PythonOperator(
    task_id="model_training",
    python_callable=train_model,
    dag=dag,
)

# Task 7: Model Evaluation
def evaluate_model(**kwargs):
    ti = kwargs["ti"]
    run_id = ti.xcom_pull(key="run_id", task_ids="model_training")
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)

    X_test = pd.read_csv("/opt/airflow/dags/X_test.csv")
    y_test = pd.read_csv("/opt/airflow/dags/y_test.csv").squeeze()

    # Load model from pickle
    with open("/opt/airflow/dags/model.pkl", "rb") as f:
        model = pickle.load(f)

    y_pred = model.predict(X_test)

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec  = recall_score(y_test, y_pred)
    f1   = f1_score(y_test, y_pred)

    with mlflow.start_run(run_id=run_id):
        mlflow.log_metric("accuracy", acc)
        mlflow.log_metric("precision", prec)
        mlflow.log_metric("recall", rec)
        mlflow.log_metric("f1_score", f1)

    ti.xcom_push(key="accuracy", value=acc)
    print(f"Accuracy:{acc:.4f} Precision:{prec:.4f} Recall:{rec:.4f} F1:{f1:.4f}")

task_evaluate = PythonOperator(
    task_id="model_evaluation",
    python_callable=evaluate_model,
    dag=dag,
)

# Task 8: Branching
def branch_logic(**kwargs):
    acc = kwargs["ti"].xcom_pull(key="accuracy", task_ids="model_evaluation")
    print(f"Accuracy = {acc:.4f}")
    return "register_model" if acc >= 0.80 else "reject_model"

task_branch = BranchPythonOperator(
    task_id="branch_on_accuracy",
    python_callable=branch_logic,
    dag=dag,
)

# Task 9a: Register Model
def register_model(**kwargs):
    run_id = kwargs["ti"].xcom_pull(key="run_id", task_ids="model_training")
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
    result = mlflow.register_model(f"runs:/{run_id}/model", "TitanicSurvivalModel")
    print(f"Model registered! Version: {result.version}")

task_register = PythonOperator(
    task_id="register_model",
    python_callable=register_model,
    dag=dag,
)

# Task 9b: Reject Model
def reject_model(**kwargs):
    ti = kwargs["ti"]
    acc = ti.xcom_pull(key="accuracy", task_ids="model_evaluation")
    run_id = ti.xcom_pull(key="run_id", task_ids="model_training")
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
    with mlflow.start_run(run_id=run_id):
        mlflow.set_tag("rejection_reason", f"Accuracy {acc:.4f} below 0.80")
    print(f"Model rejected. Accuracy {acc:.4f} < 0.80")

task_reject = PythonOperator(
    task_id="reject_model",
    python_callable=reject_model,
    dag=dag,
)

# End
task_end = DummyOperator(
    task_id="pipeline_end",
    trigger_rule="none_failed_min_one_success",
    dag=dag,
)

# Dependencies
task_ingest >> task_validate >> [task_missing, task_features] >> task_encode
task_encode >> task_train >> task_evaluate >> task_branch
task_branch >> [task_register, task_reject] >> task_end
